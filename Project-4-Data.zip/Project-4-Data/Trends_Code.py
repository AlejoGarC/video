# Importing libraries
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats


# ---------------------------------------------------------------------------
# 0) Paths and settings
# ---------------------------------------------------------------------------
# The paths are built from the location of this .py, so the project works
# from any folder (for example the one written above).
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "Datasets")
RESULTS_DIR = os.path.join(BASE_DIR, "Results")

time_series_file = os.path.join(DATA_DIR, "time_series_Worldwide_20161001-0000_20261026-1328.csv")
region_file = os.path.join(DATA_DIR, "by_region_Worldwide_20161001-0000_20261026-1328.csv")

terms = ["solar energy", "wind energy", "hydropower"]
timeframe = "2016-10-01 2026-10-26"

# True = try to download the data with Pytrends first.
# If Pytrends is not installed or Google blocks the request, the program
# uses the CSV files downloaded from https://trends.google.com (Datasets folder).
USE_PYTRENDS = False

sns.set_style("whitegrid")
colors = {"solar energy": "#F2A900", "wind energy": "#1F77B4", "hydropower": "#2CA02C"}


def save_figure(group, number):
    """Saves the current figure as Results/Results_<group>/RESULTADO<group>.<number>.png"""
    folder = os.path.join(RESULTS_DIR, f"Results_{group}")
    os.makedirs(folder, exist_ok=True)
    plt.tight_layout()
    plt.savefig(os.path.join(folder, f"RESULTADO{group}.{number}.png"), dpi=150)
    plt.show()


# ---------------------------------------------------------------------------
# 1) Data collection (Pytrends or CSV files from Google Trends)
# ---------------------------------------------------------------------------
def load_with_pytrends():
    from pytrends.request import TrendReq
    pytrends = TrendReq(hl="en-US", tz=300)
    pytrends.build_payload(terms, timeframe=timeframe, geo="")

    time_df = pytrends.interest_over_time().reset_index()
    time_df = time_df.rename(columns={"date": "Time"})
    # Pytrends marks the incomplete last period with isPartial
    time_df = time_df.drop(columns=["isPartial"])

    region_df = pytrends.interest_by_region(resolution="COUNTRY", inc_low_vol=False)
    region_df = region_df.reset_index().rename(columns={"geoName": "Region"})
    return time_df, region_df


source = "CSV files (Google Trends website)"
if USE_PYTRENDS:
    try:
        time_df, region_df = load_with_pytrends()
        source = "Pytrends API"
    except Exception as error:
        print("Pytrends could not download the data:", error)
        print("Using the CSV files of the Datasets folder instead.\n")
        time_df = pd.read_csv(time_series_file)
        region_df = pd.read_csv(region_file)
else:
    time_df = pd.read_csv(time_series_file)
    region_df = pd.read_csv(region_file)

print("Data source:", source)
print("\nFirst 5 rows of the time series:")
print(time_df.head())
print("\nInformation of the time series:")
time_df.info()
print("\nFirst 5 rows of the regional data:")
print(region_df.head())


# ---------------------------------------------------------------------------
# 2) Data cleaning and preprocessing
# ---------------------------------------------------------------------------
print("\n------------------ DATA CLEANING ------------------")

# 2.1 Google Trends writes "<1" when the interest is very low -> 0
for term in terms:
    time_df[term] = pd.to_numeric(time_df[term].replace("<1", 0), errors="coerce")
    region_df[term] = pd.to_numeric(region_df[term].replace("<1", 0), errors="coerce")

# 2.2 Date format
time_df["Time"] = pd.to_datetime(time_df["Time"])

# 2.3 Duplicates
print("Duplicated dates:", time_df.duplicated(subset="Time").sum())
time_df = time_df.drop_duplicates(subset="Time")
print("Duplicated countries:", region_df.duplicated(subset="Region").sum())
region_df = region_df.drop_duplicates(subset="Region")

# 2.4 Consistent time intervals: one row for the first day of every month
time_df = time_df.sort_values("Time").set_index("Time")
time_df = time_df.resample("MS").mean()   # monthly frequency (Month Start)
print("Rows after forcing a monthly frequency:", len(time_df))

# 2.5 The last month is incomplete (the data was downloaded on 2026-10-26),
# so it is not comparable with full months and it is removed.
last_month = time_df.index.max()
download_date = pd.to_datetime(timeframe.split()[1])
if download_date < last_month + pd.offsets.MonthEnd(0):
    print(f"Removing incomplete month: {last_month.date()} -> {time_df.loc[last_month].to_dict()}")
    time_df = time_df.drop(index=last_month)

# 2.6 Missing values
print("\nNumber of missing data in each column:\n", time_df.isna().sum())
print("Number of missing countries' values:\n", region_df.isna().sum())
time_df = time_df.fillna(time_df.mean())
region_df = region_df.dropna()

print(f"\nClean time series: {len(time_df)} months, from {time_df.index.min().date()} to {time_df.index.max().date()}")
print(f"Clean regional data: {len(region_df)} countries")

# 2.7 Handling missing data (same example of the class): we simulate 2% of
# missing values in a copy of the data and fill them with the mean, to see
# how much error that technique would add.
np.random.seed(42)
simulated = time_df.copy()
missing_rows = simulated.sample(frac=0.02).index
simulated.loc[missing_rows, "solar energy"] = None
print("\nSimulated missing values:", simulated["solar energy"].isna().sum())
simulated["solar energy"] = simulated["solar energy"].fillna(simulated["solar energy"].mean())
mean_error = (simulated.loc[missing_rows, "solar energy"] - time_df.loc[missing_rows, "solar energy"]).abs().mean()
print(f"Average error of the mean imputation: {mean_error:.2f} points")


# ---------------------------------------------------------------------------
# 3) Data transformation and feature engineering
# ---------------------------------------------------------------------------
df = time_df.reset_index()
df["Year"] = df["Time"].dt.year
df["Month"] = df["Time"].dt.month
df["Month_name"] = df["Time"].dt.strftime("%b")

# Seasons of the northern hemisphere (most of the searches come from there)
season_bins = [0, 2, 5, 8, 11, 12]
season_labels = ["Winter", "Spring", "Summer", "Autumn", "Winter "]
df["Season"] = pd.cut(df["Month"], bins=season_bins, labels=season_labels, right=True)
df["Season"] = df["Season"].astype(str).str.strip()

# Long format (melt), like in the seaborn examples
long_df = df.melt(id_vars=["Time", "Year", "Month", "Month_name", "Season"],
                  value_vars=terms, var_name="Term", value_name="Interest")

# Min-max normalization (0-1) of each term to compare their shape
normalized = time_df.copy()
for term in terms:
    normalized[term] = (time_df[term] - time_df[term].min()) / (time_df[term].max() - time_df[term].min())

# Share of each term in the total interest of every month
share = time_df.div(time_df.sum(axis=1), axis=0) * 100

# Year over year growth (shift of 12 months)
yoy = (time_df - time_df.shift(12)) / time_df.shift(12) * 100


# ---------------------------------------------------------------------------
# 4) Exploratory data analysis
# ---------------------------------------------------------------------------
print("\n------------------ EXPLORATORY ANALYSIS ------------------")
print("\nSummary statistics:")
print(time_df.describe())

yearly = df.groupby("Year")[terms].mean()
print("\nAverage interest per year:")
print(yearly.round(1))

# The seasonality is measured before the big jump of Aug-2025, so the
# months of the jump do not change the normal monthly pattern
df_before = df[df["Time"] < "2025-08-01"]

monthly_pattern = df_before.groupby("Month_name")[terms].mean()
month_order = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
monthly_pattern = monthly_pattern.reindex(month_order)
print("\nAverage interest per month (seasonality, Oct 2016 - Jul 2025):")
print(monthly_pattern.round(1))

season_pattern = df_before.groupby("Season")[terms].mean().reindex(["Winter", "Spring", "Summer", "Autumn"])
print("\nAverage interest per season (Oct 2016 - Jul 2025):")
print(season_pattern.round(1))

print("\nAverage share of the total interest (%):")
print(share.mean().round(1))

# Period before and after the big jump of August 2025
before = time_df.loc[:"2025-07-01"]
after = time_df.loc["2025-08-01":]
print("\nAverage interest before Aug-2025:\n", before.mean().round(1))
print("Average interest since Aug-2025:\n", after.mean().round(1))
print("Share before Aug-2025 (%):\n", share.loc[:"2025-07-01"].mean().round(1))
print("Share since Aug-2025 (%):\n", share.loc["2025-08-01":].mean().round(1))


# ---------------------------------------------------------------------------
# 5) Anomaly detection (spikes in interest)
# ---------------------------------------------------------------------------
print("\n------------------ ANOMALY DETECTION ------------------")

# 5.1 Z-score-based anomaly detection
z_scores = (time_df - time_df.mean()) / time_df.std()
z_threshold = 2
for term in terms:
    spikes = time_df.loc[z_scores[term] > z_threshold, term]
    print(f"\n{term} - months with z-score > {z_threshold}: {len(spikes)}")
    print(spikes)

# 5.2 Median-based anomaly detection (more robust to the spikes themselves)
for term in terms:
    x = time_df[term]
    median = np.median(x)
    threshold = 2 * np.std(x)
    outliers = []
    for date, item in x.items():
        if abs(item - median) > threshold:
            outliers.append(date.strftime("%Y-%m"))
    print(f"{term} - median-based outliers: {outliers}")

# 5.3 Comparing periods: the 2022 energy crisis spike
spring_2022 = time_df.loc["2022-02-01":"2022-05-01"].mean()
spring_2021 = time_df.loc["2021-02-01":"2021-05-01"].mean()
print("\nFeb-May 2021 average:\n", spring_2021.round(1))
print("Feb-May 2022 average (energy crisis):\n", spring_2022.round(1))


# ---------------------------------------------------------------------------
# 6) Statistical tests (like in Example 3)
# ---------------------------------------------------------------------------
print("\n------------------ STATISTICAL TESTS ------------------")

# Correlation between the three terms
corr_matrix = time_df.corr()
print("\nCorrelation matrix:")
print(corr_matrix.round(3))

# ANOVA: is the interest different between seasons? (seasonality test)
# The test is done before Aug-2025 so the jump does not hide the seasonal effect
for term in terms:
    anova_results = stats.f_oneway(
        df_before[df_before["Season"] == "Winter"][term],
        df_before[df_before["Season"] == "Spring"][term],
        df_before[df_before["Season"] == "Summer"][term],
        df_before[df_before["Season"] == "Autumn"][term],
    )
    print(f"ANOVA seasons - {term}: F-statistic: {anova_results.statistic:.3f}, P-value: {anova_results.pvalue:.6f}")

# T-test: interest in 2022 vs 2021 (energy crisis)
for term in terms:
    t_stat, p_value = stats.ttest_ind(df[df["Year"] == 2022][term], df[df["Year"] == 2021][term])
    print(f"T-test 2022 vs 2021 - {term}: T-statistic: {t_stat:.3f}, P-value: {p_value:.6f}")


# Cohen's d: size of the jump of Aug-2025
def cohen_d(x, y):
    nx = len(x)
    ny = len(y)
    dof = nx + ny - 2
    mean_diff = x.mean() - y.mean()
    pooled_std = (((nx - 1) * x.std() ** 2 + (ny - 1) * y.std() ** 2) / dof) ** 0.5
    return mean_diff / pooled_std


for term in terms:
    print(f"Cohen's d (since Aug-2025 vs before) - {term}: {cohen_d(after[term], before[term]):.2f}")

# Shapiro-Wilk normality test
for term in terms:
    shapiro_test = stats.shapiro(time_df[term])
    print(f"Shapiro-Wilk - {term}: Statistic={shapiro_test.statistic:.3f}, p-value={shapiro_test.pvalue:.6f}")

# Linear trend (regression of the interest against time) before Aug-2025
months_number = np.arange(len(before))
print("\nLinear trend before Aug-2025 (points per year):")
trend_lines = {}
for term in terms:
    regression = stats.linregress(months_number, before[term])
    trend_lines[term] = regression
    print(f"{term}: slope = {regression.slope * 12:.2f} points/year, R-squared = {regression.rvalue ** 2:.3f}, P-value = {regression.pvalue:.6f}")


# ---------------------------------------------------------------------------
# 7) Regional analysis
# ---------------------------------------------------------------------------
print("\n------------------ REGIONAL ANALYSIS ------------------")
print("In the 'Compared breakdown by region' of Google Trends, each country's values")
print("sum 100: they show how the interest is divided among the three terms.\n")
region_df["Total"] = region_df[terms].sum(axis=1)
print("Rows that sum 100 (+/-1 by rounding):", (region_df["Total"].between(99, 101)).sum(), "of", len(region_df))

print("\nRegional summary statistics:")
print(region_df[terms].describe().round(1))

for term in terms:
    top = region_df.sort_values(by=term, ascending=False).head(5)
    print(f"\nTop 5 countries - {term}:")
    print(top[["Region", term]].to_string(index=False))

region_df["Dominant"] = region_df[terms].idxmax(axis=1)
dominant_counts = region_df["Dominant"].value_counts()
print("\nDominant source per country:")
print(dominant_counts)
print("\nCountries where solar energy is NOT the dominant term:")
print(region_df[region_df["Dominant"] != "solar energy"][["Region"] + terms].to_string(index=False))

# Groups of countries by the share of solar energy (pd.cut)
region_df["Solar_group"] = pd.cut(region_df["solar energy"], bins=[0, 50, 60, 70, 100],
                                  labels=["<50%", "50-60%", "60-70%", ">70%"])
print("\nCountries per solar share group:")
print(region_df["Solar_group"].value_counts().sort_index())

region_corr = region_df[terms].corr()
print("\nCorrelation between the regional shares:")
print(region_corr.round(3))


# ---------------------------------------------------------------------------
# 8) Visualizations (saved in the Results folder)
# ---------------------------------------------------------------------------

# ===== Results 1: Trends over time =====
plt.figure(figsize=(12, 5))
sns.lineplot(data=long_df, x="Time", y="Interest", hue="Term", palette=colors, linewidth=2)
plt.axvspan(pd.to_datetime("2022-02-01"), pd.to_datetime("2022-05-01"), color="grey", alpha=0.2, label="2022 energy crisis")
plt.axvline(pd.to_datetime("2025-08-01"), color="red", linestyle="--", label="Jump Aug-2025")
plt.title("Worldwide search interest in renewable energy (Oct 2016 - Sep 2026)")
plt.xlabel("Year")
plt.ylabel("Interest (0-100)")
plt.legend(title="Term")
save_figure(1, 1)

ax = yearly.plot(kind="bar", figsize=(12, 5), color=[colors[t] for t in terms], edgecolor="black")
for container in ax.containers:
    ax.bar_label(container, fmt="%.0f", fontsize=8)
plt.title("Average interest per year")
plt.xlabel("Year")
plt.ylabel("Average interest")
plt.xticks(rotation=0)
plt.legend(title="Term")
save_figure(1, 2)

plt.figure(figsize=(12, 5))
for term in terms:
    plt.plot(normalized.index, normalized[term], label=term, color=colors[term])
plt.title("Normalized interest (min-max 0-1): the three terms follow the same shape")
plt.xlabel("Year")
plt.ylabel("Normalized interest")
plt.legend()
save_figure(1, 3)

plt.figure(figsize=(12, 5))
plt.stackplot(share.index, share["solar energy"], share["wind energy"], share["hydropower"],
              labels=terms, colors=[colors[t] for t in terms], alpha=0.8)
plt.title("Share of each term in the total monthly interest (%)")
plt.xlabel("Year")
plt.ylabel("Share (%)")
plt.legend(loc="upper left")
plt.ylim(0, 100)
save_figure(1, 4)

# ===== Results 2: Seasonal patterns =====
plt.figure(figsize=(12, 5))
sns.barplot(data=long_df[long_df["Time"] < "2025-08-01"], x="Month_name", y="Interest", hue="Term",
            order=month_order, palette=colors)
plt.title("Average interest per month (Oct 2016 - Jul 2025)")
plt.xlabel("Month")
plt.ylabel("Average interest")
save_figure(2, 1)

pivot_solar = df.pivot(index="Year", columns="Month_name", values="solar energy")[month_order]
plt.figure(figsize=(12, 6))
sns.heatmap(pivot_solar, annot=True, fmt=".0f", cmap="YlOrRd", linewidths=0.5)
plt.title("Solar energy: interest per year and month")
plt.xlabel("Month")
plt.ylabel("Year")
save_figure(2, 2)

plt.figure(figsize=(12, 5))
sns.boxplot(data=df_before, x="Month_name", y="solar energy", order=month_order, color=colors["solar energy"])
plt.title("Distribution of solar energy interest per month (Oct 2016 - Jul 2025)")
plt.xlabel("Month")
plt.ylabel("Interest")
save_figure(2, 3)

plt.figure(figsize=(10, 5))
sns.boxplot(data=long_df[long_df["Time"] < "2025-08-01"], x="Season", y="Interest", hue="Term",
            order=["Winter", "Spring", "Summer", "Autumn"], palette=colors)
plt.title("Interest per season of the northern hemisphere (Oct 2016 - Jul 2025)")
plt.xlabel("Season")
plt.ylabel("Interest")
save_figure(2, 4)

# ===== Results 3: Anomalies and spikes =====
plt.figure(figsize=(12, 5))
for term in terms:
    plt.plot(z_scores.index, z_scores[term], label=term, color=colors[term])
    spikes = z_scores[z_scores[term] > z_threshold]
    plt.scatter(spikes.index, spikes[term], color="red", zorder=3)
plt.axhline(z_threshold, color="red", linestyle="--", label=f"z = {z_threshold}")
plt.title("Z-score of the interest: red points are anomalies (z > 2)")
plt.xlabel("Year")
plt.ylabel("Z-score")
plt.legend()
save_figure(3, 1)

plt.figure(figsize=(12, 5))
x = time_df["solar energy"]
mean = x.mean()
std = x.std()
plt.plot(x.index, x, color=colors["solar energy"], label="solar energy")
plt.fill_between(x.index, mean - std, mean + std, color="grey", alpha=0.2, label="mean +/- 1 std")
plt.axhline(mean, color="black", linestyle="--", label=f"mean = {mean:.1f}")
outliers = x[(x < mean - 2 * std) | (x > mean + 2 * std)]
plt.scatter(outliers.index, outliers, color="red", zorder=3, label="outliers (> 2 std)")
plt.title("Solar energy: mean-based anomaly detection")
plt.xlabel("Year")
plt.ylabel("Interest")
plt.legend()
save_figure(3, 2)

plt.figure(figsize=(12, 5))
for term in terms:
    plt.plot(yoy.index, yoy[term], label=term, color=colors[term])
plt.axhline(0, color="black", linewidth=1)
plt.title("Year over year growth of the interest (%)")
plt.xlabel("Year")
plt.ylabel("Growth vs same month of previous year (%)")
plt.legend()
save_figure(3, 3)

plt.figure(figsize=(12, 5))
for term in terms:
    sns.histplot(time_df[term], bins=20, kde=True, color=colors[term], label=term, alpha=0.5)
plt.title("Distribution of the monthly interest values")
plt.xlabel("Interest")
plt.ylabel("Frequency")
plt.legend()
save_figure(3, 4)

# ===== Results 4: Regional comparison =====
top_regions = pd.concat([region_df.sort_values(by=t, ascending=False).head(5) for t in terms]).drop_duplicates("Region")
top_long = top_regions.melt(id_vars="Region", value_vars=terms, var_name="Term", value_name="Share")
plt.figure(figsize=(13, 6))
ax = sns.barplot(data=top_long, x="Region", y="Share", hue="Term", palette=colors)
for container in ax.containers:
    ax.bar_label(container, fontsize=7)
plt.title("Top 5 countries of each term: share of the interest (%)")
plt.xlabel("Country")
plt.ylabel("Share of interest (%)")
plt.xticks(rotation=45, ha="right")
save_figure(4, 1)

selected = ["Colombia", "United States", "Brazil", "Mexico", "India", "China", "Germany",
            "United Kingdom", "Spain", "Canada", "Australia", "Nigeria", "Norway", "Denmark", "Nepal"]
heat_data = region_df[region_df["Region"].isin(selected)].set_index("Region")[terms]
heat_data = heat_data.sort_values(by="solar energy", ascending=False)
plt.figure(figsize=(8, 8))
sns.heatmap(heat_data, annot=True, fmt=".0f", cmap="coolwarm", linewidths=0.5)
plt.title("Share of interest by country (%)")
plt.xlabel("Term")
plt.ylabel("Country")
save_figure(4, 2)

group_counts = region_df["Solar_group"].value_counts().sort_index()
plt.figure(figsize=(9, 5))
bars = plt.bar(group_counts.index.astype(str), group_counts.values, color=colors["solar energy"], edgecolor="black")
for bar in bars:
    plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.3, f"{bar.get_height()}",
             ha="center", va="bottom", color="black", fontsize=12, weight="bold")
plt.title(f"Countries per share of solar energy (solar is dominant in {dominant_counts['solar energy']} of {len(region_df)} countries)")
plt.xlabel("Solar energy share of the interest")
plt.ylabel("Number of countries")
save_figure(4, 3)

region_long = region_df.melt(id_vars="Region", value_vars=terms, var_name="Term", value_name="Share")
plt.figure(figsize=(10, 5))
sns.boxplot(data=region_long, x="Term", y="Share", hue="Term", palette=colors)
plt.title("Distribution of the share of interest across countries")
plt.xlabel("Term")
plt.ylabel("Share of interest (%)")
save_figure(4, 4)

# ===== Results 5: Relationships and trend =====
plt.figure(figsize=(7, 6))
sns.heatmap(corr_matrix, annot=True, cmap="coolwarm", fmt=".2f", vmin=-1, vmax=1)
plt.title("Correlation between the monthly interest of the terms")
save_figure(5, 1)

g = sns.jointplot(data=time_df, x="solar energy", y="wind energy", kind="reg", height=7, color="purple")
g.fig.suptitle("Solar energy vs wind energy (monthly interest)", y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(RESULTS_DIR, "Results_5", "RESULTADO5.2.png"), dpi=150, bbox_inches="tight")
plt.show()

plt.figure(figsize=(12, 5))
for term in terms:
    reg = trend_lines[term]
    plt.plot(before.index, before[term], color=colors[term], alpha=0.5, label=term)
    plt.plot(before.index, reg.intercept + reg.slope * months_number, color=colors[term], linestyle="--",
             linewidth=2, label=f"trend {term} ({reg.slope * 12:+.2f}/year)")
plt.title("Linear trend of the interest before the jump (Oct 2016 - Jul 2025)")
plt.xlabel("Year")
plt.ylabel("Interest")
plt.legend(fontsize=8, ncol=2)
save_figure(5, 3)

plt.figure(figsize=(9, 7))
sns.scatterplot(data=region_df, x="solar energy", y="hydropower", hue="Dominant", palette=colors, s=70)
for i in range(len(region_df)):
    row = region_df.iloc[i]
    if row["hydropower"] > 25 or row["solar energy"] > 77 or row["Dominant"] != "solar energy":
        plt.text(row["solar energy"] + 0.8, row["hydropower"] + 0.8, row["Region"], fontsize=8)
plt.title("Countries: solar energy share vs hydropower share")
plt.xlabel("Solar energy share (%)")
plt.ylabel("Hydropower share (%)")
save_figure(5, 4)

print("\nAll the figures were saved in:", RESULTS_DIR)
